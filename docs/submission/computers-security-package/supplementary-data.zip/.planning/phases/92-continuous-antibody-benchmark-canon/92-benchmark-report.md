# Phase 92 Benchmark Report

- Generated at: 2026-04-03T03:56:20.961752+00:00
- Baseline reference: `data/benchmarks/v9.2-baseline.json`
- Source surface: saved continuous score artifact from Plan 92-01
- Scope guard: Phase 92 preserves the Phase 84 swarm NO-GO and does not add detector families or swarm terms.

## Score Quality

Continuous score-quality and calibration metrics are reported separately from policy overlays.

### control_equal
- weights: {'NegSel': 0.5, 'OCSVM': 0.5}
- confidence_mode: mean
- headline: average_precision=1.000 | roc_auc=1.000 | brier_loss=0.068 | ece=0.237 | avg_latency_ms=5.000 | peak_memory_mb=33.000

### weighted_ocsvm_0.20_negsel_0.80
- weights: {'NegSel': 0.8, 'OCSVM': 0.2}
- confidence_mode: mean
- headline: average_precision=1.000 | roc_auc=1.000 | brier_loss=0.083 | ece=0.245 | avg_latency_ms=5.000 | peak_memory_mb=33.000

### weighted_ocsvm_0.35_negsel_0.65
- weights: {'NegSel': 0.65, 'OCSVM': 0.35}
- confidence_mode: mean
- headline: average_precision=1.000 | roc_auc=1.000 | brier_loss=0.075 | ece=0.241 | avg_latency_ms=5.000 | peak_memory_mb=33.000

### weighted_ocsvm_0.50_negsel_0.50
- weights: {'NegSel': 0.5, 'OCSVM': 0.5}
- confidence_mode: mean
- headline: average_precision=1.000 | roc_auc=1.000 | brier_loss=0.068 | ece=0.237 | avg_latency_ms=5.000 | peak_memory_mb=33.000

### weighted_ocsvm_0.65_negsel_0.35
- weights: {'NegSel': 0.35, 'OCSVM': 0.65}
- confidence_mode: mean
- headline: average_precision=1.000 | roc_auc=1.000 | brier_loss=0.062 | ece=0.234 | avg_latency_ms=5.000 | peak_memory_mb=33.000

### weighted_ocsvm_0.80_negsel_0.20
- weights: {'NegSel': 0.2, 'OCSVM': 0.8}
- confidence_mode: mean
- headline: average_precision=1.000 | roc_auc=1.000 | brier_loss=0.056 | ece=0.230 | avg_latency_ms=5.000 | peak_memory_mb=33.000

### confidence_modulated_static
- weights: {'NegSel': 0.35, 'OCSVM': 0.65}
- confidence_mode: weighted_by_confidence
- headline: average_precision=1.000 | roc_auc=1.000 | brier_loss=0.062 | ece=0.233 | avg_latency_ms=5.000 | peak_memory_mb=33.000

## Policy Overlays

Decision policies are post-hoc overlays on the saved score surfaces above. They do not rerun detectors.

### global_threshold

#### confidence_modulated_static
- selection: {"threshold": 0.5}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000
- paired_delta_vs_control_equal: {"balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0}

#### control_equal
- selection: {"threshold": 0.5}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000
- paired_delta_vs_control_equal: {"balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0}

#### weighted_ocsvm_0.20_negsel_0.80
- selection: {"threshold": 0.5}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000
- paired_delta_vs_control_equal: {"balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0}

#### weighted_ocsvm_0.35_negsel_0.65
- selection: {"threshold": 0.5}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000
- paired_delta_vs_control_equal: {"balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0}

#### weighted_ocsvm_0.50_negsel_0.50
- selection: {"threshold": 0.5}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000
- paired_delta_vs_control_equal: {"balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0}

#### weighted_ocsvm_0.65_negsel_0.35
- selection: {"threshold": 0.5}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000
- paired_delta_vs_control_equal: {"balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0}

#### weighted_ocsvm_0.80_negsel_0.20
- selection: {"threshold": 0.5}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000
- paired_delta_vs_control_equal: {"balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0}

### domain_thresholds

#### confidence_modulated_static
- selection: {"thresholds_by_domain": {"hallucination": 0.5, "prompt_injection": 0.5}}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000
- paired_delta_vs_control_equal: {"balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0}

#### control_equal
- selection: {"thresholds_by_domain": {"hallucination": 0.5, "prompt_injection": 0.5}}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000
- paired_delta_vs_control_equal: {"balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0}

#### weighted_ocsvm_0.20_negsel_0.80
- selection: {"thresholds_by_domain": {"hallucination": 0.5, "prompt_injection": 0.5}}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000
- paired_delta_vs_control_equal: {"balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0}

#### weighted_ocsvm_0.35_negsel_0.65
- selection: {"thresholds_by_domain": {"hallucination": 0.5, "prompt_injection": 0.5}}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000
- paired_delta_vs_control_equal: {"balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0}

#### weighted_ocsvm_0.50_negsel_0.50
- selection: {"thresholds_by_domain": {"hallucination": 0.5, "prompt_injection": 0.5}}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000
- paired_delta_vs_control_equal: {"balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0}

#### weighted_ocsvm_0.65_negsel_0.35
- selection: {"thresholds_by_domain": {"hallucination": 0.5, "prompt_injection": 0.5}}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000
- paired_delta_vs_control_equal: {"balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0}

#### weighted_ocsvm_0.80_negsel_0.20
- selection: {"thresholds_by_domain": {"hallucination": 0.5, "prompt_injection": 0.5}}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000
- paired_delta_vs_control_equal: {"balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0}

### operator_multiband

#### confidence_modulated_static
- selection: {"high_threshold": 0.5, "low_threshold": 0.493536, "min_confidence": 0.6}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000 | review_rate=0.000 | auto_decision_coverage=1.000
- paired_delta_vs_control_equal: {"auto_decision_coverage_delta": 0.0, "balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0, "review_rate_delta": 0.0}
- decision_counts: {"allow": 2, "block": 2, "review": 0}
- bands: allow, review, block

#### control_equal
- selection: {"high_threshold": 0.5, "low_threshold": 0.495, "min_confidence": 0.6}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000 | review_rate=0.000 | auto_decision_coverage=1.000
- paired_delta_vs_control_equal: {"auto_decision_coverage_delta": 0.0, "balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0, "review_rate_delta": 0.0}
- decision_counts: {"allow": 2, "block": 2, "review": 0}
- bands: allow, review, block

#### weighted_ocsvm_0.20_negsel_0.80
- selection: {"high_threshold": 0.5, "low_threshold": 0.498, "min_confidence": 0.6}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000 | review_rate=0.000 | auto_decision_coverage=1.000
- paired_delta_vs_control_equal: {"auto_decision_coverage_delta": 0.0, "balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0, "review_rate_delta": 0.0}
- decision_counts: {"allow": 2, "block": 2, "review": 0}
- bands: allow, review, block

#### weighted_ocsvm_0.35_negsel_0.65
- selection: {"high_threshold": 0.5, "low_threshold": 0.4965, "min_confidence": 0.6}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000 | review_rate=0.000 | auto_decision_coverage=1.000
- paired_delta_vs_control_equal: {"auto_decision_coverage_delta": 0.0, "balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0, "review_rate_delta": 0.0}
- decision_counts: {"allow": 2, "block": 2, "review": 0}
- bands: allow, review, block

#### weighted_ocsvm_0.50_negsel_0.50
- selection: {"high_threshold": 0.5, "low_threshold": 0.495, "min_confidence": 0.6}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000 | review_rate=0.000 | auto_decision_coverage=1.000
- paired_delta_vs_control_equal: {"auto_decision_coverage_delta": 0.0, "balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0, "review_rate_delta": 0.0}
- decision_counts: {"allow": 2, "block": 2, "review": 0}
- bands: allow, review, block

#### weighted_ocsvm_0.65_negsel_0.35
- selection: {"high_threshold": 0.5, "low_threshold": 0.4935, "min_confidence": 0.6}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000 | review_rate=0.000 | auto_decision_coverage=1.000
- paired_delta_vs_control_equal: {"auto_decision_coverage_delta": 0.0, "balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0, "review_rate_delta": 0.0}
- decision_counts: {"allow": 2, "block": 2, "review": 0}
- bands: allow, review, block

#### weighted_ocsvm_0.80_negsel_0.20
- selection: {"high_threshold": 0.5, "low_threshold": 0.492, "min_confidence": 0.6}
- metrics: precision=1.000 | recall=1.000 | f1=1.000 | balanced_accuracy=1.000 | policy_reward=1.000 | review_rate=0.000 | auto_decision_coverage=1.000
- paired_delta_vs_control_equal: {"auto_decision_coverage_delta": 0.0, "balanced_accuracy_delta": 0.0, "f1_delta": 0.0, "policy_reward_delta": 0.0, "precision_delta": 0.0, "recall_delta": 0.0, "review_rate_delta": 0.0}
- decision_counts: {"allow": 2, "block": 2, "review": 0}
- bands: allow, review, block
