# ADR: Phase 84 Swarm GO/NO-GO Gate

## Status

Accepted

## Context

Phase 84 exists to test a narrow hypothesis, not to justify a framework build by momentum. The measured v9.2 flat-ensemble baseline is already strong on the four existing domains:

- `hallucination` F1 `0.9533`
- `code_security` F1 `0.9725`
- `reasoning` F1 `0.9333`
- `bio` F1 `1.0000`

Phase 83 also removed the old determinism rationale for swarm work. The observed stability result was:

- `exact` variance `0.00%` vs target `>15.0%` -> failed
- `semantic` variance `0.00%` vs target `<5.0%` -> passed

That means swarm cannot be justified as a determinism fix by story alone. It must clear the Phase 84 bar on measured evidence from [phase84-swarm-spike.json](/Users/byron/projects/active/antigence-bittensor/data/benchmarks/phase84-swarm-spike.json).

## Options Considered

1. `GO`: authorize Phase 85 if the thin `IsolationForest + OCSVM + NegSel` spike beats the immutable baseline by `>0.03` absolute F1 on at least two domains, stays under `<2x` latency, has a plausible mechanism, and shows no unmitigable adversarial issue.
2. `NO-GO`: reject swarm if the thin spike fails any gate criterion and continue on the weighted-ensemble path.
3. "Proceed anyway because the roadmap already has swarm phases": rejected up front because it violates the Phase 84 hypothesis-first constraint.

## Measured Results

Source artifact: [phase84-swarm-spike.json](/Users/byron/projects/active/antigence-bittensor/data/benchmarks/phase84-swarm-spike.json)

### Hallucination

- Baseline F1: `0.9533`
- `mean3` F1: `0.6854` (`-0.2679` vs baseline), latency multiplier `4.9477x`
- `median3` F1: `0.5700` (`-0.3833` vs baseline), latency multiplier `4.9477x`

### Code Security

- Baseline F1: `0.9725`
- `mean3` F1: `0.1854` (`-0.7871` vs baseline), latency multiplier `8.3941x`
- `median3` F1: `0.1928` (`-0.7797` vs baseline), latency multiplier `8.3941x`

### Reasoning

- Baseline F1: `0.9333`
- `mean3` F1: `0.3947` (`-0.5386` vs baseline), latency multiplier `5.2987x`
- `median3` F1: `0.3448` (`-0.5885` vs baseline), latency multiplier `5.2987x`

### Bio

- Baseline F1: `1.0000`
- `mean3` F1: `0.5333` (`-0.4667` vs baseline), latency multiplier `5.2279x`
- `median3` F1: `0.4932` (`-0.5068` vs baseline), latency multiplier `5.2279x`

## Adversarial Findings

The spike included a one-extreme-agent perturbation that replaced the IsolationForest score with `1.0` to test whether one extreme detector vote could distort the aggregate.

- `mean3` max flip rate: `0.8136` with `179` prediction flips
- `median3` max flip rate: `0.7455` with `164` prediction flips

This is not a mild robustness concern. Under the defined probe, both aggregators remain highly sensitive to a single extreme detector vote.

## Mechanism Analysis

The thin spike has only one plausible mechanism: detector diversification from adding IsolationForest to the existing `OCSVM + NegSel` control. The measured artifact shows no support for that mechanism:

- `mean3` improved on zero domains relative to the measured baseline
- `median3` improved on zero domains relative to the measured baseline
- Both aggregators also underperformed the current two-detector control on every domain
- Any observed difference between `mean3` and `median3` is an aggregation-choice effect, not evidence for a richer swarm mechanism

Because Phase 83 observed `0.00%` variance in both `exact` and `semantic` modes, there is also no remaining basis to argue that swarm should proceed as a determinism-only mitigation.

## Decision

**NO-GO**

The thin Phase 84 spike fails every decision bar from D-02.

### Gate Evaluation

1. `>0.03` absolute F1 gain on at least two domains: failed.
   - `mean3`: `0` domains
   - `median3`: `0` domains

2. `<2x` latency: failed.
   - Best case observed multiplier was still `4.9477x`
   - Worst case observed multiplier was `8.3941x`

3. Plausible mechanism: failed.
   - The only plausible mechanism was detector diversification.
   - Measured results show no gain over either the immutable baseline or the current two-detector control.

4. No unmitigable adversarial issue: failed.
   - Both `mean3` and `median3` show large flip rates under the one-extreme-agent probe.

## Consequences

- Phases `85-91` are **skipped by gate**.
- Phase 85 is **not authorized** and must **not** be implemented from this result.
- The milestone continues on the weighted-ensemble / non-determinism-hardening path, not a swarm framework path.
- Any future revisit would require a new phase with a new hypothesis and new evidence, not reinterpretation of this artifact.
